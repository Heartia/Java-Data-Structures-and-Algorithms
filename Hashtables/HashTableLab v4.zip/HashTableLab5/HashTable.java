package HashTableLab5;

import java.util.ArrayList;
import java.util.Random;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class HashTable {

    Node[] nodes;
    int size;
    int nodeAmt;

    HashTable() {
        nodes = new Node[101];
        size = 0;
        nodeAmt = 0;
    }

    HashTable(int initCap) {
        nodes = new Node[initCap];
        size = 0;
        nodeAmt = 0;
    }

    Object put(Object key, Object value) {
        Node newNode = new Node(key, value);
        int hashIndex = key.hashCode() % nodes.length;
        if (nodes[hashIndex] == null) {
            nodeAmt++;
            size++;
            nodes[hashIndex] = newNode;
            return null;
        }
        if (nodes[hashIndex].key.equals(key)) {
            Node successor = nodes[hashIndex].next;
            newNode.next = successor;
            nodes[hashIndex] = newNode;
            return successor;
        }
        Node currNode = nodes[hashIndex];
        Node previousNode = currNode;
        while (currNode != null && !currNode.key.equals(key)) {
            previousNode = currNode;
            currNode = currNode.next;
        }

        if (currNode == null) {
            nodeAmt++;
            previousNode.next = newNode;
            return null;
        }
        else {
            nodeAmt++;
            newNode.next = currNode;
            previousNode.next = newNode;
            return currNode.value;
        }
    }

    Object get(Object key) {
        int hashIndex = key.hashCode() % nodes.length;
        Node currNode = nodes[hashIndex];
        while (currNode != null && !currNode.key.equals(key)) {
            currNode = currNode.next;
        }
        return currNode != null ? currNode.value : null;
    }

    Object remove(Object key) {
        int hashIndex = key.hashCode() % nodes.length;
        Node currNode = nodes[hashIndex];
        if (currNode == null) {
            return null;
        }
        if (currNode.key.equals(key)) {
            nodes[hashIndex] = currNode.next;
            nodeAmt--;
            if (nodes[hashIndex] == null) {
                size--;
            }
            return currNode.value;
        }
        while (currNode != null && !currNode.key.equals(key)) {
            currNode = currNode.next;
        }
        if (currNode == null) {
            return null;
        }
        else if (currNode.key.equals(key)) {
            nodeAmt--;
            Node searchNode = nodes[hashIndex];
            while (!searchNode.next.key.equals(key)) {
                searchNode = searchNode.next;
            }
            searchNode.next = currNode.next;
            return currNode;
        }
        return null;
    }

    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder("{");
        for (Node node : nodes) {
            Node currNode = node;
            while (currNode != null) {
                builder.append(currNode).append(", ");
                currNode = currNode.next;
            }
        }
        return builder.toString().substring(0, builder.toString().length() - 2) + "}";
    }

    class Node {

        Object key, value;
        Node next;

        Node() {
            key = value = null;
        }

        Node(Object key, Object value) {
            this.key = key;
            this.value = value;
        }

        @Override
        public String toString() {
            return "{" +
                    "k = " + key +
                    ", v = " + value +
                    '}';
        }
    }

}
