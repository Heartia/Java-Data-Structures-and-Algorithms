package HashTableLab6;

import java.util.ArrayList;
import java.util.Random;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class ChainHashTable extends HashTable {

    int size;
    int nodeAmt;

    ChainHashTable() {
        nodes = new Node[101];
        size = 0;
        nodeAmt = 0;
        putCounter = 0;
        getCounter = 0;
    }

    ChainHashTable(int initCap) {
        nodes = new Node[initCap];
        size = 0;
        nodeAmt = 0;
        putCounter = 0;
        getCounter = 0;
    }

    @Override
    Object put(Object key, Object value) {
        Node newNode = new Node(key, value);
        int hashIndex = Math.abs(key.hashCode()) % nodes.length;
        putCounter++;
        if (nodes[hashIndex] == null) {
            nodeAmt++;
            size++;
            nodes[hashIndex] = newNode;
            return null;
        }
        if (nodes[hashIndex].key.equals(key)) {
            Node successor = nodes[hashIndex].next;
            newNode.next = successor;
            nodes[hashIndex] = newNode;
            return successor;
        }
        Node currNode = nodes[hashIndex];
        Node previousNode = currNode;
        while (currNode != null && !currNode.key.equals(key)) {
            putCounter++;
            previousNode = currNode;
            currNode = currNode.next;
        }

        if (currNode == null) {
            nodeAmt++;
            previousNode.next = newNode;
            return null;
        }
        else {
            nodeAmt++;
            newNode.next = currNode;
            previousNode.next = newNode;
            return currNode.value;
        }
    }

    @Override
    Object get(Object key) {
        int hashIndex = Math.abs(key.hashCode()) % nodes.length;
        Node currNode = nodes[hashIndex];
        getCounter++;
        while (currNode != null && !currNode.key.equals(key)) {
            currNode = currNode.next;
            getCounter++;
        }
        return currNode != null ? currNode.value : null;
    }

    @Override
    Object remove(Object key) {
        int hashIndex = Math.abs(key.hashCode()) % nodes.length;
        Node currNode = nodes[hashIndex];
        if (currNode == null) {
            return null;
        }
        if (currNode.key.equals(key)) {
            nodes[hashIndex] = currNode.next;
            nodeAmt--;
            if (nodes[hashIndex] == null) {
                size--;
            }
            return currNode.value;
        }
        while (currNode != null && !currNode.key.equals(key)) {
            currNode = currNode.next;
        }
        if (currNode == null) {
            return null;
        }
        else if (currNode.key.equals(key)) {
            nodeAmt--;
            Node searchNode = nodes[hashIndex];
            while (!searchNode.next.key.equals(key)) {
                searchNode = searchNode.next;
            }
            searchNode.next = currNode.next;
            return currNode;
        }
        return null;
    }

    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder("{");
        for (Node node : nodes) {
            Node currNode = node;
            while (currNode != null) {
                builder.append(currNode).append(", ");
                currNode = currNode.next;
            }
        }
        return builder.toString().substring(0, builder.toString().length() - 2) + "}";
    }

}
