package HashTableLab6;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Random;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class RandomHashTable extends HashTable {

    Node[] nodes;
    int[] perms;
    int size;

    RandomHashTable() {
        nodes = new Node[101];
        perms = new int[101];
        perms[0] = 0;
        Random random = new Random(7460);
        ArrayList<Integer> values = (ArrayList<Integer>) IntStream.rangeClosed(1, 100).boxed().collect(Collectors.toList());
        for (int i = 1; i < perms.length; i++) {
            perms[i] = values.remove(random.nextInt(values.size()));
        }
        System.out.println(Arrays.toString(perms));
        size = 0;
        putCounter = 0;
        getCounter = 0;
    }

    RandomHashTable(int initCap) {
        nodes = new Node[initCap];
        perms = new int[nodes.length];
        Random random = new Random(7460);
        ArrayList<Integer> values = (ArrayList<Integer>) IntStream.rangeClosed(1, nodes.length - 1).boxed().collect(Collectors.toList());
        for (int i = 1; i < perms.length; i++) {
            perms[i] = values.remove(random.nextInt(values.size()));
        }
        size = 0;
        putCounter = 0;
        getCounter = 0;
    }

    Object put(Object key, Object value) {
        if (size + 1 != nodes.length) {
            Node newNode = new Node(key, value);
            int hashIndex = Math.abs(key.hashCode()) % nodes.length;
            putCounter++;
            if (nodes[hashIndex] == null) {
                nodes[hashIndex] = newNode;
                size++;
                return null;
            }
            else {
                if (nodes[hashIndex].key.equals(key)) {
                    Object returnVal = nodes[hashIndex];
                    nodes[hashIndex] = newNode;
                    return returnVal;
                }
                else {
                    // Pseudorandom Probing
                    int permIndex = 0;
                    int searchIndex = perms[permIndex];
                    while (permIndex + 1 < perms.length) {
                        putCounter++;
                        if (nodes[searchIndex] == null) {
                            nodes[searchIndex] = newNode;
                            size++;
                            return null;
                        }
                        else if (nodes[searchIndex].key.equals(key)) {
                            if (nodes[searchIndex].removed) {
                                nodes[searchIndex] = newNode;
                                size++;
                                return null;
                            }
                            nodes[searchIndex] = newNode;
                            return nodes[searchIndex].value;
                        }
                        permIndex++;
                        searchIndex = perms[permIndex];
                    }
                }
                return null;
            }
        }
        else {
            throw new IllegalStateException("Hashtable is full");
        }
    }

    Object get(Object key) {
        int hashIndex = Math.abs(key.hashCode()) % nodes.length;
        getCounter++;
        if (nodes[hashIndex] != null && !nodes[hashIndex].removed) {
            if (nodes[hashIndex].key.equals(key)) {
                return nodes[hashIndex].value;
            }
            else {
                // Pseudorandom Probing
                int permIndex = 0;
                int searchIndex = perms[permIndex];
                while (permIndex + 1 < perms.length) {
                    getCounter++;
                    if (nodes[searchIndex] == null) {
                        return null;
                    }
                    else if (nodes[searchIndex].key.equals(key)) {
                        if (nodes[searchIndex].removed) {
                            return null;
                        }
                        return nodes[searchIndex].value;
                    }
                    permIndex++;
                    searchIndex = perms[permIndex];
                }
            }
        }
        return null;
    }

    Object remove(Object key) {
        int hashIndex = Math.abs(key.hashCode()) % nodes.length;
        if (nodes[hashIndex] != null && !nodes[hashIndex].removed) {
            if (nodes[hashIndex].key.equals(key)) {
                Object returnVal = nodes[hashIndex].value;
                nodes[hashIndex].remove();
                size--;
                return returnVal;
            }
            else {
                // Pseudorandom Probing
                int permIndex = 0;
                int searchIndex = perms[permIndex];
                while (permIndex + 1 < perms.length) {
                    if (nodes[searchIndex] == null) {
                        return null;
                    }
                    else if (nodes[searchIndex].key.equals(key)) {
                        if (nodes[searchIndex].removed) {
                            return null;
                        }
                        nodes[searchIndex].remove();
                        return nodes[searchIndex].value;
                    }
                    permIndex++;
                    searchIndex = perms[permIndex];
                }
            }
        }
        return null;
    }

    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder("{");
        for (Node node : nodes) {
            if (node != null) {
                builder.append(node).append(", ");
            }
        }
        return builder.toString().substring(0, builder.toString().length() - 2) + "}";
    }

    public int getPuts() {
        return putCounter;
    }

    public int getGets() {
        return getCounter;
    }

    class Node {

        Object key, value;
        boolean removed;

        Node() {
            key = value = null;
        }

        Node(Object key, Object value) {
            this.key = key;
            this.value = value;
        }

        void remove() {
            removed = true;
        }

        @Override
        public String toString() {
            if (!removed) {
                return "{" +
                        "k = " + key +
                        ", v = " + value +
                        '}';
            }
            else {
                return "dummy";
            }
        }
    }

}
