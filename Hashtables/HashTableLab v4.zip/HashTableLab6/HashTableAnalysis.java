package HashTableLab6;

import java.io.*;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;

public class HashTableAnalysis {

    enum TableType {
        LINEAR, QUADRATIC, PSEUDORANDOM, CHAIN;
    }

    public static void main(String[] args) throws IOException {
        ArrayList<String> largeDataSet = new ArrayList<>(),
                successfulSearch = new ArrayList<>(),
                unsuccessfulSearch = new ArrayList<>();

        BufferedReader br = new BufferedReader(new FileReader(new File("Large Data Set.txt")));

        String line;
        while ((line = br.readLine()) != null) {
            largeDataSet.add(line);
        }

        br = new BufferedReader(new FileReader(new File("Successful Search Records.txt")));

        while ((line = br.readLine()) != null) {
            successfulSearch.add(line);
        }

        br = new BufferedReader(new FileReader(new File("Unsuccessful Search Records.txt")));

        while ((line = br.readLine()) != null) {
            unsuccessfulSearch.add(line);
        }

        br.close();
        analyse(0.1f, largeDataSet, successfulSearch, unsuccessfulSearch, TableType.LINEAR);
        analyse(0.5f, largeDataSet, successfulSearch, unsuccessfulSearch, TableType.LINEAR);
        analyse(0.8f, largeDataSet, successfulSearch, unsuccessfulSearch, TableType.LINEAR);
        analyse(0.9f, largeDataSet, successfulSearch, unsuccessfulSearch, TableType.LINEAR);
        analyse(0.99f, largeDataSet, successfulSearch, unsuccessfulSearch, TableType.LINEAR);
        System.out.println("\n##################\n##################\n");
        analyse(0.1f, largeDataSet, successfulSearch, unsuccessfulSearch, TableType.QUADRATIC);
        analyse(0.5f, largeDataSet, successfulSearch, unsuccessfulSearch, TableType.QUADRATIC);
        analyse(0.8f, largeDataSet, successfulSearch, unsuccessfulSearch, TableType.QUADRATIC);
        analyse(0.9f, largeDataSet, successfulSearch, unsuccessfulSearch, TableType.QUADRATIC);
        analyse(0.99f, largeDataSet, successfulSearch, unsuccessfulSearch, TableType.QUADRATIC);
        System.out.println("\n##################\n##################\n");
        analyse(0.1f, largeDataSet, successfulSearch, unsuccessfulSearch, TableType.PSEUDORANDOM);
        analyse(0.5f, largeDataSet, successfulSearch, unsuccessfulSearch, TableType.PSEUDORANDOM);
        analyse(0.8f, largeDataSet, successfulSearch, unsuccessfulSearch, TableType.PSEUDORANDOM);
        analyse(0.9f, largeDataSet, successfulSearch, unsuccessfulSearch, TableType.PSEUDORANDOM);
        analyse(0.99f, largeDataSet, successfulSearch, unsuccessfulSearch, TableType.PSEUDORANDOM);
        System.out.println("\n##################\n##################\n");
        analyse(0.1f, largeDataSet, successfulSearch, unsuccessfulSearch, TableType.CHAIN);
        analyse(0.5f, largeDataSet, successfulSearch, unsuccessfulSearch, TableType.CHAIN);
        analyse(0.8f, largeDataSet, successfulSearch, unsuccessfulSearch, TableType.CHAIN);
        analyse(0.9f, largeDataSet, successfulSearch, unsuccessfulSearch, TableType.CHAIN);
        analyse(0.99f, largeDataSet, successfulSearch, unsuccessfulSearch, TableType.CHAIN);
    }

    private static void analyse(float loadFactour, List<String> dataSet, List<String> success, List<String> unsuccess, TableType tableType) {
        HashTable table = new LinearHashTable((int)Math.round((Math.pow(loadFactour, -1) * dataSet.size())));

        if (tableType.equals(TableType.LINEAR)) {
            table = new LinearHashTable((int)Math.round((Math.pow(loadFactour, -1) * dataSet.size())));
            System.out.println("Linear Probing\nLoad Factor: " + loadFactour + "\nBuild Table");
        }
        else if (tableType.equals(TableType.QUADRATIC)) {
            table = new QuadraticHashTable((int)Math.round((Math.pow(loadFactour, -1) * dataSet.size())));
            System.out.println("Quadratic Probing\nLoad Factor: " + loadFactour + "\nBuild Table");
        }
        else if (tableType.equals(TableType.PSEUDORANDOM)) {
            table = new RandomHashTable((int)Math.round((Math.pow(loadFactour, -1) * dataSet.size())));
            System.out.println("Pseudorandom Probing\nLoad Factor: " + loadFactour + "\nBuild Table");
        }
        else if (tableType.equals(TableType.CHAIN)) {
            table = new ChainHashTable((int)Math.round((Math.pow(loadFactour, -1) * dataSet.size())));
            System.out.println("Chaining\nLoad Factor: " + loadFactour + "\nBuild Table");
        }
        long start = System.currentTimeMillis();

        for (int i = 0; i < dataSet.size(); i++) {
            String[] parsed = dataSet.get(i).split("\\s");
            StringBuilder valueInfo = new StringBuilder();
            /*
            for (int v = 0; v < parsed.length - 1; v++) {
                valueInfo.append(parsed[v]).append(" ");
            }
            table.put(Long.parseLong(parsed[parsed.length - 1].trim()), valueInfo.toString().trim());
             */
            for (int v = 2; v < parsed.length; v++) {
                valueInfo.append(parsed[v]).append(" ");
            }
            table.put((parsed[0] + " " + parsed[1]).trim(), valueInfo.toString().trim());
        }

        System.out.println("Build time: " + (System.currentTimeMillis() - start));
        System.out.println("Objects visited: " + table.putCounter);

        start = System.currentTimeMillis();
        System.out.println("\nSuccessful Searches");
        for (int i = 0; i < success.size(); i++) {
            String[] parsed = success.get(i).split("\\s");
            //table.get(Long.parseLong(parsed[parsed.length - 1]));
            table.get((parsed[0] + " " + parsed[1]).trim());
        }
        System.out.println("Search time: " + (System.currentTimeMillis() - start));
        System.out.println("Objects visited: " + table.getGets());

        table.putCounter = 0;

        start = System.currentTimeMillis();
        System.out.println("\nUnsuccessful Searches");
        for (int i = 0; i < unsuccess.size(); i++) {
            String[] parsed = unsuccess.get(i).split("\\s");
            //table.get(Long.parseLong(parsed[parsed.length - 1]));
            table.get((parsed[0] + " " + parsed[1]).trim());
        }
        System.out.println("Search time: " + (System.currentTimeMillis() - start));
        System.out.println("Objects visited: " + table.getGets());
        System.out.println("\n##################\n");
    }

}
