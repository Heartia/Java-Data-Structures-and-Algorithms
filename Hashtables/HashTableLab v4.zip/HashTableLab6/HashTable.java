package HashTableLab6;

public abstract class HashTable {

    int putCounter, getCounter;
    Node[] nodes;

    abstract Object put(Object key, Object value);
    abstract Object get(Object key);
    abstract Object remove(Object key);

    public int getPuts() {
        return putCounter;
    }

    public int getGets() {
        return getCounter;
    }

    class Node {

        Object key, value;
        Node next;

        Node() {
            key = value = null;
        }

        Node(Object key, Object value) {
            this.key = key;
            this.value = value;
        }

        @Override
        public String toString() {
            return "{" +
                    "k = " + key +
                    ", v = " + value +
                    '}';
        }
    }

}
