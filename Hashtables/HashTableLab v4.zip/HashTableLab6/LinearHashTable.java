package HashTableLab6;

public class LinearHashTable extends HashTable {

    Node[] nodes;
    int size;

    LinearHashTable() {
        nodes = new Node[101];
        size = 0;
        putCounter = 0;
        getCounter = 0;
    }

    LinearHashTable(int initCap) {
        nodes = new Node[initCap];
        size = 0;
        putCounter = 0;
        getCounter = 0;
    }

    Object put(Object key, Object value) {
        if (size + 1 != nodes.length) {
            Node newNode = new Node(key, value);
            int hashIndex = Math.abs(key.hashCode()) % nodes.length;
            putCounter++;
            if (nodes[hashIndex] == null) {
                nodes[hashIndex] = newNode;
                size++;
                return null;
            }
            else {
                if (nodes[hashIndex].key.equals(key)) {
                    Object returnVal = nodes[hashIndex];
                    nodes[hashIndex] = newNode;
                    return returnVal;
                }
                else {
                    // Linear Probing
                    int searchIndex = (hashIndex + 1) % (nodes.length - 1);
                    while (searchIndex != hashIndex) {
                        putCounter++;
                        if (nodes[searchIndex] == null) {
                            nodes[searchIndex] = newNode;
                            size++;
                            return null;
                        }
                        else if (nodes[searchIndex].key.equals(key)) {
                            if (nodes[searchIndex].removed) {
                                nodes[searchIndex] = newNode;
                                size++;
                                return null;
                            }
                            nodes[searchIndex] = newNode;
                            return nodes[searchIndex].value;
                        }
                        searchIndex = (searchIndex + 1) % (nodes.length - 1);
                    }
                }
                return null;
            }
        }
        else {
            throw new IllegalStateException("Hashtable is full");
        }
    }

    Object get(Object key) {
        int hashIndex = Math.abs(key.hashCode()) % nodes.length;
        getCounter++;
        if (nodes[hashIndex] != null && !nodes[hashIndex].removed) {
            if (nodes[hashIndex].key.equals(key)) {
                return nodes[hashIndex].value;
            }
            else {
                // Linear Probing
                int searchIndex = (hashIndex + 1) % (nodes.length - 1);
                while (searchIndex != hashIndex) {
                    getCounter++;
                    if (nodes[searchIndex] == null) {
                        return null;
                    }
                    else if (nodes[searchIndex].key.equals(key)) {
                        if (nodes[searchIndex].removed) {
                            return null;
                        }
                        return nodes[searchIndex].value;
                    }
                    searchIndex = (searchIndex + 1) % (nodes.length - 1);
                }
            }
        }
        return null;
    }

    Object remove(Object key) {
        int hashIndex = Math.abs(key.hashCode()) % nodes.length;
        if (nodes[hashIndex] != null && !nodes[hashIndex].removed) {
            if (nodes[hashIndex].key.equals(key)) {
                Object returnVal = nodes[hashIndex].value;
                nodes[hashIndex].remove();
                size--;
                return returnVal;
            }
            else {
                // Linear Probing
                int searchIndex = (hashIndex + 1) % (nodes.length - 1);
                while (searchIndex != hashIndex) {
                    if (nodes[searchIndex] == null) {
                        return null;
                    }
                    else if (nodes[searchIndex].key.equals(key)) {
                        if (nodes[searchIndex].removed) {
                            return null;
                        }
                        nodes[searchIndex].remove();
                        return nodes[searchIndex].value;
                    }
                    searchIndex = (searchIndex + 1) % (nodes.length - 1);
                }
            }
        }
        return null;
    }

    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder("{");
        for (Node node : nodes) {
            if (node != null) {
                builder.append(node).append(", ");
            }
        }
        return builder.toString().substring(0, builder.toString().length() - 2) + "}";
    }

    public int getPuts() {
        return putCounter;
    }

    public int getGets() {
        return getCounter;
    }

    class Node {

        Object key, value;
        boolean removed;

        Node() {
            key = value = null;
        }

        Node(Object key, Object value) {
            this.key = key;
            this.value = value;
        }

        void remove() {
            removed = true;
        }

        @Override
        public String toString() {
            if (!removed) {
                return "{" +
                        "k = " + key +
                        ", v = " + value +
                        '}';
            }
            else {
                return "dummy";
            }
        }
    }

}
