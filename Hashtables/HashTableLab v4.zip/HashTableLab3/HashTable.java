package HashTableLab3;

public class HashTable {

    Node[] nodes;
    int size;
    private final int MAX_INCREMENT = (int)Math.sqrt(Integer.MAX_VALUE);

    HashTable() {
        nodes = new Node[101];
        size = 0;
    }

    HashTable(int initCap) {
        nodes = new Node[initCap];
        size = 0;
    }

    Object put(Object key, Object value) {
        if (size + 1 != nodes.length) {
            Node newNode = new Node(key, value);
            int hashIndex = key.hashCode() % nodes.length;
            if (nodes[hashIndex] == null) {
                nodes[hashIndex] = newNode;
                size++;
                return null;
            }
            else {
                if (nodes[hashIndex].key.equals(key)) {
                    Object returnVal = nodes[hashIndex];
                    nodes[hashIndex] = newNode;
                    return returnVal;
                }
                else {
                    // Quadratic Probing
                    int increment = 1;
                    int searchIndex = (hashIndex + increment * increment) % (nodes.length - 1);
                    while (increment < MAX_INCREMENT) {
                        if (nodes[searchIndex] == null) {
                            nodes[searchIndex] = newNode;
                            size++;
                            return null;
                        }
                        else if (nodes[searchIndex].key.equals(key)) {
                            if (nodes[searchIndex].removed) {
                                nodes[searchIndex] = newNode;
                                size++;
                                return null;
                            }
                            nodes[searchIndex] = newNode;
                            return nodes[searchIndex].value;
                        }
                        increment++;
                        searchIndex = (hashIndex + increment * increment) % (nodes.length - 1);
                    }
                }
                return null;
            }
        }
        else {
            throw new IllegalStateException("Hashtable is full");
        }
    }

    Object get(Object key) {
        int hashIndex = key.hashCode() % nodes.length;
        if (nodes[hashIndex] != null && !nodes[hashIndex].removed) {
            if (nodes[hashIndex].key.equals(key)) {
                return nodes[hashIndex].value;
            }
            else {
                // Quadratic Probing
                int increment = 1;
                int searchIndex = (hashIndex + increment * increment) % (nodes.length - 1);
                while (increment < MAX_INCREMENT) {
                    if (nodes[searchIndex] == null) {
                        return null;
                    }
                    else if (nodes[searchIndex].key.equals(key)) {
                        if (nodes[searchIndex].removed) {
                            return null;
                        }
                        return nodes[searchIndex].value;
                    }
                    increment++;
                    searchIndex = (hashIndex + increment * increment) % (nodes.length - 1);
                }
            }
        }
        return null;
    }

    Object remove(Object key) {
        int hashIndex = key.hashCode() % nodes.length;
        if (nodes[hashIndex] != null && !nodes[hashIndex].removed) {
            if (nodes[hashIndex].key.equals(key)) {
                Object returnVal = nodes[hashIndex].value;
                nodes[hashIndex].remove();
                size--;
                return returnVal;
            }
            else {
                // Quadratic Probing
                int increment = 1;
                int searchIndex = (hashIndex + increment * increment) % (nodes.length - 1);
                while (increment < MAX_INCREMENT) {
                    if (nodes[searchIndex] == null) {
                        return null;
                    }
                    else if (nodes[searchIndex].key.equals(key)) {
                        if (nodes[searchIndex].removed) {
                            return null;
                        }
                        nodes[searchIndex].remove();
                        return nodes[searchIndex].value;
                    }
                    increment++;
                    searchIndex = (hashIndex + increment * increment) % (nodes.length - 1);
                }
            }
        }
        return null;
    }

    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder("{");
        for (Node node : nodes) {
            if (node != null) {
                builder.append(node).append(", ");
            }
        }
        return builder.toString().substring(0, builder.toString().length() - 2) + "}";
    }

    class Node {

        Object key, value;
        boolean removed;

        Node() {
            key = value = null;
        }

        Node(Object key, Object value) {
            this.key = key;
            this.value = value;
        }

        void remove() {
            removed = true;
        }

        @Override
        public String toString() {
            if (!removed) {
                return "{" +
                        "k = " + key +
                        ", v = " + value +
                        '}';
            }
            else {
                return "dummy";
            }
        }
    }

}
