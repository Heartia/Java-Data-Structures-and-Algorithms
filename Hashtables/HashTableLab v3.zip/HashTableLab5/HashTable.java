package HashTableLab5;

import java.util.ArrayList;
import java.util.Random;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class HashTable {

    Node[] nodes;
    int[] perms;
    int size;

    HashTable() {
        nodes = new Node[101];
        perms = new int[101];
        Random random = new Random(7460);
        ArrayList<Integer> values = (ArrayList<Integer>) IntStream.rangeClosed(0, 100).boxed().collect(Collectors.toList());
        for (int i = 0; i < perms.length; i++) {
            perms[i] = values.remove(random.nextInt(values.size()));
        }
        size = 0;
    }

    HashTable(int initCap) {
        nodes = new Node[initCap];
        perms = new int[nodes.length];
        Random random = new Random(7460);
        ArrayList<Integer> values = (ArrayList<Integer>) IntStream.rangeClosed(0, nodes.length - 1).boxed().collect(Collectors.toList());
        for (int i = 0; i < perms.length; i++) {
            perms[i] = values.remove(random.nextInt(values.size()));
        }
        size = 0;
    }

    Object put(Object key, Object value) {
        if (size + 1 != nodes.length) {
            Node newNode = new Node(key, value);
            int hashIndex = key.hashCode() % nodes.length;
            if (nodes[hashIndex] == null) {
                nodes[hashIndex] = newNode;
                return null;
            }
            if (nodes[hashIndex].key.equals(key)) {
                Node successor = nodes[hashIndex].next;
                newNode.next = successor;
                nodes[hashIndex] = newNode;
                return successor;
            }
            Node currNode = nodes[hashIndex];
            while (currNode != null && !currNode.key.equals(key)) {
                currNode = currNode.next;
            }

            return null;
        }
        else {
            throw new IllegalStateException("Hashtable is full");
        }
    }

    Object get(Object key) {
        int hashIndex = key.hashCode() % nodes.length;
        Node currNode = nodes[hashIndex];
        while (currNode != null && !currNode.key.equals(key)) {
            currNode = currNode.next;
        }
        return currNode != null ? currNode.value : null;
    }

    Object remove(Object key) {
        int hashIndex = key.hashCode() % nodes.length;
        Node currNode = nodes[hashIndex];
        if (currNode == null) {
            return null;
        }
        if (currNode.key.equals(key)) {
            nodes[hashIndex] = currNode.next;
            return currNode.value;
        }
        while (currNode != null && !currNode.key.equals(key)) {
            currNode = currNode.next;
        }
        if (currNode == null) {
            return null;
        }
        if (currNode.key.equals(key)) {
            Node searchNode = nodes[hashIndex];
            while (!searchNode.next.key.equals(key)) {
                searchNode = searchNode.next;
            }
            searchNode.next = currNode.next;
            return currNode;
        }
        return null;
    }

    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder("{");
        for (Node node : nodes) {
            if (node != null) {
                builder.append(node).append(", ");
            }
        }
        return builder.toString().substring(0, builder.toString().length() - 2) + "}";
    }

    class Node {

        Object key, value;
        Node next;

        Node() {
            key = value = null;
        }

        Node(Object key, Object value) {
            this.key = key;
            this.value = value;
        }

        @Override
        public String toString() {
            return "{" +
                    "k = " + key +
                    ", v = " + value +
                    '}';
        }
    }

}
