package HashTableLab5;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

public class TableTester {

    public static void main(String[] args) throws IOException {
        HashTable table = new HashTable();
        BufferedReader br = new BufferedReader(new FileReader(new File("Data_W_Colls.dat")));

        String line;
        while ((line = br.readLine()) != null) {
            int key = Integer.parseInt(line.substring(0, 8));
            String value = line.substring(9);
            table.put(key, value);
            System.out.println(table.get(key) + " : " + table.size);
        }

        System.out.println("*********************************************");


        try {
            table.put(64, "MARIO MARIO");
        }
        catch(IllegalStateException e) {
            System.out.println("Hashtable is full");
        }
        System.out.println(table.get(92800393));
        System.out.println(table.size);
        System.out.println(table.get(64357276));
        System.out.println(table.size);
        System.out.println(table.get(55051198));
        System.out.println(table.size);
        System.out.println(table.get(92800393));
        System.out.println(table.size);
        System.out.println(table.remove(96732358));
        System.out.println(table.size);
        System.out.println(table.get(77777777));
        System.out.println(table.size);
        System.out.println(table.remove(92800393));
        System.out.println(table.size);
        System.out.println(table.remove(77777777));
        System.out.println(table.size);
        System.out.println(table.get(92800393));
        System.out.println(table.size);
        System.out.println(table);
    }

}
