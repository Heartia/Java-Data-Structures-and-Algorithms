package HashTableLab;

public class Node {

    public Object key, value;

    Node() {
        key = value = null;
    }

    Node(Object key, Object value) {
        this.key = key;
        this.value = value;
    }

    @Override
    public String toString() {
        return "{" +
                "k = " + key +
                ", v = " + value +
                '}';
    }
}
