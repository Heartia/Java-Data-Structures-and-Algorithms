package HashTableLab;

import java.util.Arrays;

public class HashTable {

    Node[] nodes;

    HashTable() {
        nodes = new Node[101];
    }

    HashTable(int initCap) {
        nodes = new Node[initCap];
    }

    Object put(Object key, Object value) {
        Node newNode = new Node(key, value);
        int hashIndex = key.hashCode() % nodes.length;
        Object returnVal = nodes[hashIndex];
        nodes[hashIndex] = newNode;
        return returnVal;
    }

    Object get(Object key) {
        int hashIndex = key.hashCode() % nodes.length;
        if (nodes[hashIndex].key.equals(key)) {
            return nodes[hashIndex].value;
        }
        return null;
    }

    Object remove(Object key) {
        int hashIndex = key.hashCode() % nodes.length;
        if (nodes[hashIndex].key.equals(key)) {
            Object returnVal = nodes[hashIndex].value;
            nodes[hashIndex] = null;
            return returnVal;
        }
        return null;
    }

    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder("{");
        for (Node node : nodes) {
            if (node != null) {
                builder.append(node).append(", ");
            }
        }
        return builder.toString().substring(0, builder.toString().length() - 2) + "}";
    }
}
